let screen = '#DECEBA';
let radius = 25;

function setup() {
  createCanvas(500, 500);
  frameRate(10);
  ellipseMode(RADIUS);
}

function draw() {
  background('#DB856E');
  stroke('black');
  
    textAlign(CENTER);
  textSize(14);
  text(`x: ${mouseX} y: ${mouseY}`, 45, 20);
  
  if ((mouseX > 150) && (mouseY > 435) && (mouseX < 150+50) && (mouseY < 435+ 50)) {
    if (mouseClicked) {
   screen = " #DBBA6E"; 
  } 
    
}
  if ((dist(250, 460, mouseX, mouseY) > radius) < radius) {
  if (mouseIsPressed) {
   screen = "#DECEBA"; 
  } 
} 
  
   if ((dist(350, 460, mouseX, mouseY)) < radius)  {
  if (keyIsPressed) {
   screen = "#DBAB6E"; 
  } 
} 
  fill(screen);
square(50, 25, 400)
  
  
  //wooden box tv?
  fill("#DB996E");
   ellipse(250,460,25);
   ellipse(350,460,25);
   rect(150, 435, 50);
  //knobs and buttons
}
function mouseClicked() {
}
function keyIsPressed() {
}