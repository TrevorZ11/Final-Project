  let x = 0;
  let y = 0;

function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);
 
}

function draw() {
  background('black');
 pac(mouseX, mouseY);
  
}

function pac(x, y) {
   push();
  translate(x, y);
  rotate(dist(mouseX, pmouseX, mouseY, pmouseY));
  scale(dist(mouseX, pmouseX, mouseY, pmouseY));
  fill('yellow');
  arc(10 ,10 ,20 ,35 ,20, 5);
  stroke('white');
  fill('black');
  ellipse( 10, 2, 5);
  pop();
  check(x,y);
}

function check() {
  print('works');
  
}