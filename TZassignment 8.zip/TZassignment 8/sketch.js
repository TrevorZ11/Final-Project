let name;
let nana;
let rose;

function preload() {
  name = loadImage('/assets/Name.png');
  nana = loadImage('/assets/Nana.png');
  rose = loadImage('/assets/Rose.png');
  //p.s. not my images
}

function setup() {
  createCanvas(1200, 720);
  
}

function draw() {
  background('lightblue');
   image(name, 0, 0);
  scale(0.5);
   image(nana, 600, 500);
   image(rose, mouseX, mouseY);
  type(text('Images from a game', 305, 505));
}

function type() {
   textFont('Helvetica');
   stroke('black');
   strokeWeight(12);
   fill('white');
  textSize(54);
 }